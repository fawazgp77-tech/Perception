package com.example.mobilityassist

import org.junit.Assert.*
import org.junit.Test

class DecisionEngineTest {
    private val engine = DecisionEngine()
    private fun center(height: Float) = Obstacle("person", .9f, .25f, 0f, .75f, height)
    private val left = Obstacle("dog", .9f, 0f, 0f, .2f, .8f)
    private val right = left.copy(left = .8f, right = 1f)

    @Test fun sizeThresholdsAndPriority() {
        assertEquals(Proximity.FAR, center(.1f).proximity)
        assertEquals(Proximity.NEAR, center(.16f).proximity)
        assertEquals(Proximity.VERY_NEAR, center(.5f).proximity)
        assertNull(engine.decide(listOf(center(.1f))))
        assertEquals(Warning.AHEAD, engine.decide(listOf(left, center(.2f))))
        assertEquals(Warning.STOP, engine.decide(listOf(left, right, center(.5f))))
    }
    @Test fun sideRulesAndEmptyScene() {
        assertNull(engine.decide(emptyList()))
        assertEquals(Warning.KEEP_RIGHT, engine.decide(listOf(left)))
        assertEquals(Warning.KEEP_LEFT, engine.decide(listOf(right)))
        assertEquals(Warning.AHEAD, engine.decide(listOf(left, right)))
    }
    @Test fun regionBoundaries() {
        assertEquals(Region.CENTER, left.copy(left = 1f / 3, right = 1f / 3).region)
        assertEquals(Region.RIGHT, left.copy(left = 2f / 3, right = 2f / 3).region)
    }
    @Test fun cooldownAndUrgentPreemption() {
        val gate = WarningGate()
        assertTrue(gate.allow(Warning.KEEP_LEFT, 0))
        assertFalse(gate.allow(Warning.KEEP_RIGHT, 100))
        assertTrue(gate.allow(Warning.STOP, 200))
        assertFalse(gate.allow(Warning.STOP, 2199))
        assertTrue(gate.allow(Warning.STOP, 2200))
        assertFalse(gate.allow(Warning.AHEAD, 2300))
        gate.reset()
        assertTrue(gate.allow(Warning.AHEAD, 2400))
    }
}
