package com.example.mobilityassist

enum class Region { LEFT, CENTER, RIGHT }
enum class Proximity { FAR, NEAR, VERY_NEAR }

// Coordinates are normalized to the upright, visible camera crop.
data class Obstacle(val label: String, val score: Float,
    val left: Float, val top: Float, val right: Float, val bottom: Float) {
    val area: Float get() = ((right - left) * (bottom - top)).coerceIn(0f, 1f)
    val region: Region get() = when {
        (left + right) / 2 < 1f / 3 -> Region.LEFT
        (left + right) / 2 < 2f / 3 -> Region.CENTER
        else -> Region.RIGHT
    }
    val proximity: Proximity get() = when {
        area >= 0.25f -> Proximity.VERY_NEAR
        area >= 0.08f -> Proximity.NEAR
        else -> Proximity.FAR
    }
}

enum class Warning(val text: String, val urgent: Boolean = false) {
    STOP("Stop. Obstacle ahead.", true),
    AHEAD("Obstacle ahead."),
    KEEP_RIGHT("Keep right."),
    KEEP_LEFT("Keep left.")
}

class DecisionEngine {
    fun decide(objects: List<Obstacle>): Warning? {
        val center = objects.filter { it.region == Region.CENTER }
        if (center.any { it.proximity == Proximity.VERY_NEAR }) return Warning.STOP
        if (center.any { it.proximity == Proximity.NEAR }) return Warning.AHEAD
        val sides = objects.filter { it.region != Region.CENTER }
        // Conflicting side guidance would direct the user toward another detection.
        if (sides.any { it.region == Region.LEFT } && sides.any { it.region == Region.RIGHT }) {
            return Warning.AHEAD
        }
        return when (sides.maxByOrNull { it.area }?.region) {
            Region.LEFT -> Warning.KEEP_RIGHT
            Region.RIGHT -> Warning.KEEP_LEFT
            else -> null
        }
    }
}

// Per-warning cooldown plus a global quiet period prevents alternating speech.
// A newly urgent STOP can interrupt a lower-priority warning immediately.
class WarningGate(private val cooldownMs: Long = 2_000) {
    private val times = mutableMapOf<Warning, Long>()
    private var lastTime: Long? = null
    fun allow(warning: Warning, nowMs: Long): Boolean {
        if (times[warning]?.let { nowMs - it < cooldownMs } == true) return false
        if (!warning.urgent && lastTime?.let { nowMs - it < cooldownMs } == true) return false
        times[warning] = nowMs
        lastTime = nowMs
        return true
    }
    fun reset() { times.clear(); lastTime = null }
}
